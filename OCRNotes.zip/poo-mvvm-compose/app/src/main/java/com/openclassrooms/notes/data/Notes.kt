package com.openclassrooms.notes.data

class Notes (val title: String, val description: String){
}